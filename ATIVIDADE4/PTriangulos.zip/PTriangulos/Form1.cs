﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulos
{
    public partial class Form1 : Form
    {
        Double lado1;
        Double lado2;
        Double lado3;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //btnVerificar
        {
            if (Double.TryParse(txtLado1.Text, out lado1) &&
               Double.TryParse(txtLado2.Text, out lado2) &&
               Double.TryParse(txtLado3.Text, out lado3))
            {
                if (Math.Abs(lado2 - lado3) < lado1 && lado1 < lado2 + lado3 &&
                  (Math.Abs(lado1 - lado3) < lado2 && lado2 < lado1 + lado3) &&
                  (Math.Abs(lado1 - lado2) < lado3 && lado3 < lado1 + lado2))
                {
                    if (lado1 == lado2 && lado2 == lado3)
                    {
                        txtResultado.Text = "Equilátero";
                    }
                    else if (lado1 != lado2 && lado2 != lado3)
                    {
                        txtResultado.Text = "Escaleno";
                    }
                    else
                        txtResultado.Text = "Isósceles";
                }
                else
                {
                    MessageBox.Show("Este triângulo é inválido!");
                }
            }
            else
            {
                MessageBox.Show("Dados Inválidos!");
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e) 
        {
            
        }
    }
}
