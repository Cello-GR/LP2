﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PContato00;

namespace PContato1
{
    internal class Contato
    {
        public int Idcontato { get; set; }

        public string NomeContato { get; set; }

        public string EndContato { get; set; }

        public int Cidadeidcidade { get; set; }

        public string CelContato { get; set; }

        public string EmailContato { get; set; }

        public DateTime DtCadastroContato { get; set; }


        public int Incluir() // INCLUSAO
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("INSERT INTO CONTATO VALUES (@nomecontato,@endcontato,@cidadeidcidade," +
                    "@celcontato,@emailcontato,@dtcadastrocontato)", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@nomecontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@endcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@cidadeidcidade", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@celcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@emailcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastrocontato", SqlDbType.Date));


                mycommand.Parameters["@nomecontato"].Value = NomeContato;
                mycommand.Parameters["@endcontato"].Value = EndContato;
                mycommand.Parameters["@cidadeidcidade"].Value = Cidadeidcidade;
                mycommand.Parameters["@celcontato"].Value = CelContato;
                mycommand.Parameters["@emailcontato"].Value = EmailContato;
                mycommand.Parameters["@dtcadastrocontato"].Value = DtCadastroContato;

                retorno = mycommand.ExecuteNonQuery();


            }
            catch (Exception)
            {
                throw;
            }

            return retorno;
        }

        public int Alterar() // alteração
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("UPDATE CONTATO SET NOME_CONTATO=@nomecontato,END_CONTATO=@endcontato," +
                    " CIDADE_ID_CIDADE=@cidadeidcidade, CEL_CONTATO=@celcontato, EMAIL_CONTATO=@emailcontato, " +
                    " DTCADASTRO_CONTATO=@dtcadastrocontato WHERE ID_CONTATO = @idcontato", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@idcontato", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@nomecontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@endcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@cidadeidcidade", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@celcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@emailcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastrocontato", SqlDbType.Date));


                mycommand.Parameters["@idcontato"].Value = Idcontato;
                mycommand.Parameters["@nomecontato"].Value = NomeContato;
                mycommand.Parameters["@endcontato"].Value = EndContato;
                mycommand.Parameters["@cidadeidcidade"].Value = Cidadeidcidade;
                mycommand.Parameters["@celcontato"].Value = CelContato;
                mycommand.Parameters["@emailcontato"].Value = EmailContato;
                mycommand.Parameters["@dtcadastrocontato"].Value = DtCadastroContato;


                retorno = mycommand.ExecuteNonQuery();

            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }

        public int Excluir() // EXCLUSÃO 
        {
            int nReg = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("DELETE FROM CONTATO WHERE ID_CONTATO=@idcontato", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@idcontato", SqlDbType.Int));
                mycommand.Parameters["@idcontato"].Value = Idcontato;

                nReg = mycommand.ExecuteNonQuery();
            }

            catch (Exception)
            {
                throw;
            }
            return nReg;
        }
        public DataTable Listar()
        {
            SqlDataAdapter daContato;

            DataTable dtContato = new DataTable();

            try
            {
                daContato = new SqlDataAdapter("SELECT * FROM CONTATO ORDER BY NOME_CONTATO", frmPrincipal.conexao);
                daContato.Fill(dtContato);
                daContato.FillSchema(dtContato, SchemaType.Source);
            }
            catch (Exception)
            {
                throw; // criar uma exceção
            }
            return dtContato;
        }
    }



}
