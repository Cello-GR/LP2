﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        Double Altura, Peso, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text = "";
            txtIMC.Text = "";
            txtIMCResult.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja mesmo sair?", "Sair", MessageBoxButtons.YesNo,
                 MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out Altura) ||
               (!Double.TryParse(txtPeso.Text, out Peso) || (Altura <= 0) || (Peso <= 0)))
            {
                MessageBox.Show("Dados Inválidos"); 
                return;
            }
            else
            {
                IMC = Peso / (Altura * Altura);
                IMC = Math.Round(IMC, 1);
                txtIMC.Text = IMC.ToString();

                if(IMC < 18.5)
                {
                    txtIMCResult.Text = "Abaixo do peso";
                }
                else if(IMC <= 25)
                {
                    txtIMCResult.Text = "Peso normal";
                }
                else if(IMC <= 30)
                {
                    txtIMCResult.Text = "Excesso de peso";
                }
                else
                {
                    txtIMCResult.Text = "Obesidade";
                }
            }
        }
    }
}
