namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = "";
            txtVolume.Clear();
        }

        private void bttnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio) || raio <= 0) {
                MessageBox.Show("Raio inv�lido!");
                txtRaio.Focus();
            }
            else if (!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura inv�lida");
                txtAltura.Focus();  //FOCUS RETORNA O FOCO
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura; // MATH = CONSTANTE DE PI E POW = POWER.
                txtVolume.Text = volume.ToString("N2"); //N2 = DOUBLE COM 2 CASAS DECIMAIS
            }


        }
    }
}
