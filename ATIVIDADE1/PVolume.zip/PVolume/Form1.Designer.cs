﻿namespace PVolume
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtRaio = new TextBox();
            txtAltura = new TextBox();
            txtVolume = new TextBox();
            bttnCalcular = new Button();
            btnFechar = new Button();
            btnLimpar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(61, 56);
            label1.Name = "label1";
            label1.Size = new Size(47, 25);
            label1.TabIndex = 0;
            label1.Text = "Raio";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(61, 139);
            label2.Name = "label2";
            label2.Size = new Size(59, 25);
            label2.TabIndex = 1;
            label2.Text = "Altura";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(61, 223);
            label3.Name = "label3";
            label3.Size = new Size(72, 25);
            label3.TabIndex = 2;
            label3.Text = "Volume";
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(286, 50);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(150, 31);
            txtRaio.TabIndex = 3;
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(286, 133);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(150, 31);
            txtAltura.TabIndex = 4;
            // 
            // txtVolume
            // 
            txtVolume.Location = new Point(286, 217);
            txtVolume.Name = "txtVolume";
            txtVolume.Size = new Size(150, 31);
            txtVolume.TabIndex = 5;
            // 
            // bttnCalcular
            // 
            bttnCalcular.Location = new Point(136, 335);
            bttnCalcular.Name = "bttnCalcular";
            bttnCalcular.Size = new Size(112, 34);
            bttnCalcular.TabIndex = 7;
            bttnCalcular.Text = "Calcular";
            bttnCalcular.UseVisualStyleBackColor = true;
            bttnCalcular.Click += bttnCalcular_Click;
            // 
            // btnFechar
            // 
            btnFechar.Location = new Point(324, 335);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(112, 34);
            btnFechar.TabIndex = 8;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(502, 335);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 9;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnLimpar);
            Controls.Add(btnFechar);
            Controls.Add(bttnCalcular);
            Controls.Add(txtVolume);
            Controls.Add(txtAltura);
            Controls.Add(txtRaio);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtRaio;
        private TextBox txtAltura;
        private TextBox txtVolume;
        private Button bttnCalcular;
        private Button btnFechar;
        private Button btnLimpar;
    }
}
